import React from 'react';
import './Card.css';
import { useNavigate } from 'react-router-dom';

interface DestinationCard {
  id: number;
  name: string;
  image: string;
}

const destinations: DestinationCard[] = [
  { id: 1, name: "Paris", image: "https://s1.1zoom.me/b5050/550/USA_Island_Skyscrapers_island_Freedom_Upper_new_593961_1920x1080.jpg" },
  { id: 2, name: "New York", image: "https://www.banburyguardian.co.uk/jpim-static/image/2023/05/16/12/AdobeStock_306619275_Editorial_Use_Only.jpeg?crop=3:2,smart&trim=&width=1200&auto=webp&quality=75" },
  { id: 3, name: "Tokyo", image: "https://s1.1zoom.me/b5050/550/USA_Island_Skyscrapers_island_Freedom_Upper_new_593961_1920x1080.jpg" },
  { id: 4, name: "London", image: "https://s1.1zoom.me/b5050/550/USA_Island_Skyscrapers_island_Freedom_Upper_new_593961_1920x1080.jpg" },
  { id: 5, name: "Rome", image: "https://s1.1zoom.me/b5050/550/USA_Island_Skyscrapers_island_Freedom_Upper_new_593961_1920x1080.jpg" },
  { id: 6, name: "Sydney", image: "https://s1.1zoom.me/b5050/550/USA_Island_Skyscrapers_island_Freedom_Upper_new_593961_1920x1080.jpg" }
];

const Card: React.FC = () => {
   const navigate= useNavigate()
  const handleCardClick = (name: string) => {
    // TODO: Implement navigation to places section
    navigate(`/places/${name}`);
    console.log(`Navigating to place with id: ${name}`);
  };

  return (
    <div className='card-cnt'>
      {/* <h2 className="section-title">Popular Destinations</h2> */}
      <h4> Travel also for </h4>
      <div className="card-grid">
        {destinations.map((dest) => (
          <div
            key={dest.id}
            className="card-item"
            style={{backgroundImage: `url('${dest.image}')`}}
            onClick={() => handleCardClick(dest.name)}
          >
            <div className="card-content">
              <h3>{dest.name}</h3>
              <button className="explore-btn">Explore</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Card;





