import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import './BusHub.css';

import { ImArrowRight2 } from "react-icons/im";
import { IoWifi } from "react-icons/io5";
import { FaWifi } from 'react-icons/fa';
import { FaBed } from "react-icons/fa";

interface BusData {
  fromdest: string;
  todest: string;
  shift: string;
  seatsAvailable: { seatNumber: number; isAvailable: boolean }[];
  busFeatures: string;
  ridetime: string;
  rideId: number;
  price: number;
  busid: number;
  busname: string;
  busno: string;
}

const BusHub: React.FC = () => {
  const param = useLocation();
  
  const [fromDestination, setFromDest] = useState<string | null>(null);
  const [toDestination, setToDestination] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [busData, setBusData] = useState<BusData[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [showSeats, setShowSeats] = useState<number | null>(null);

  useEffect(() => {
    const searchParams = new URLSearchParams(param.search);
    // if(searchParams)
    const from = searchParams.get("from");
    const to = searchParams.get("to");
    const date = searchParams.get("date");
    if(!from&&to&&date){
      return <h1>There are no Buses a man</h1>
      

    }
    setFromDest(from);
    setToDestination(to);
    setSelectedDate(date);
  }, [param.search]);

  useEffect(() => {
    if (fromDestination && toDestination) {
      async function getBuses() {
        try {
          setLoading(true);
          const response = await fetch('http://localhost:3000/routes/searchbus', {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              fromDestination: fromDestination,
              toDestination: toDestination
            })
          });


          if (!response.ok) {
            throw new Error(`Error: ${response.status} ${response.statusText}`);
            // console.log('error in feectching ')

          }
          

          const data = await response.json();
          setBusData(data);
          
  
        } catch (err) {
          setError(err instanceof Error ? err.message : "Unknown error");
        } finally {
          setLoading(false);
        }
      }

      getBuses();
    }
  }, [fromDestination, toDestination]);

  const handleViewSeats = (rideId: number) => {
    setShowSeats(showSeats === rideId ? null : rideId);
  };

  return (
    <div className='bus_hub'>
      <div className="bushub-box">
        <div className="hub-left">
          <div className="hub-left-box">
            <div className='hub-search-info'>
              <h4>Your Search</h4>
              <label>Destination</label> <br></br>
              <input placeholder='Paris'></input><br></br>
              <label>From</label><br></br>
              <input placeholder='Paris'></input>
            </div>
            {/* Filter section (to be implemented) */}
          
          </div>
          <div className="hub-places">
            {/* Places section (to be implemented) */}
          </div>
        </div>
        <div className="hub-right"> 
          <div className='hub-right-box'>
            <div className='hub-right-top'>
              <div className='h-places'>
                <h4>{fromDestination}</h4>
                <span><ImArrowRight2 /></span>
                <h4>{toDestination}</h4>
                <h4>{selectedDate}</h4>
              </div>
            </div>
            <div className="hub-buses-items">
              {loading && <p>Loading buses...</p>}
              {error && <p className="error-message">{error}</p>}
              {busData.length > 0 ? (
                busData.map((bus) => (
                  <div key={bus.rideId} className="bus-card">
                    <div className='bus-items'>
                      <div className="bus-heading">
                      <h3>{bus.busname} </h3>
                      <p className='arrival-time'>{bus.ridetime} A.M</p>
                      </div>
                    <div className='bus-info-cnt'>
                    <div className='bus-info-icons'><ul>
                   
                      <li>{<FaWifi/>}</li>
                      <li>{<FaBed/>}</li>
                      </ul></div>
                      <p>Shift: {bus.shift}</p>
                      {/* <p>Ride Time: {bus.ridetime}</p> */}
                      <p>Price: ${bus.price}</p>
                      <button className='view-seats-btn' onClick={() => handleViewSeats(bus.rideId)}>
                        {showSeats === bus.rideId ? "Hide Seats" : "View Seats"}
                      </button>
                    </div>

                    </div>
                    {showSeats === bus.rideId && (
                      <div className="seats-container">
                        <h4>Seats Available:</h4>
                        <div className="seats-grid">
                          {bus.seatsAvailable.map(seat => (
                            <div key={seat.seatNumber} className={`seat ${seat.isAvailable ? 'available' : 'unavailable'}`}>
                              {seat.seatNumber}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))
              ) : !loading && <p>No buses available for the selected route.</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BusHub;
